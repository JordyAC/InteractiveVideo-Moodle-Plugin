<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_vidinteractivo\interaction\types;

use mod_vidinteractivo\interaction\base_element;
use mod_vidinteractivo\interaction\grade_result;

defined('MOODLE_INTERNAL') || die();

final class dragdrop extends base_element {
    public function get_type(): string {
        return 'dragdrop';
    }

    public function get_name(): string {
        return get_string('type_dragdrop', 'mod_vidinteractivo');
    }

    public function grade_response(array $config, $response, float $maxscore, int $attemptnumber = 1, float $penalty = 0.0): grade_result {
        $submitted = $this->json_to_array($response);
        $mapping = $config['mapping'] ?? [];
        $iscorrect = !empty($mapping) && $submitted === $mapping;
        $score = $iscorrect ? $this->apply_penalty($maxscore, $attemptnumber, $penalty) : 0.0;
        return new grade_result($iscorrect, $score, $iscorrect ? get_string('correct', 'mod_vidinteractivo') : get_string('incorrect', 'mod_vidinteractivo'));
    }
}
