<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_vidinteractivo\interaction\types;

use mod_vidinteractivo\interaction\base_element;
use mod_vidinteractivo\interaction\grade_result;

defined('MOODLE_INTERNAL') || die();

/**
 * Multiple choice interaction. Supports single and multi-select answers.
 */
final class multiplechoice extends base_element {
    public function get_type(): string {
        return 'multiplechoice';
    }

    public function get_name(): string {
        return get_string('type_multiplechoice', 'mod_vidinteractivo');
    }

    public function normalize_config(array $config): array {
        if (isset($config['question']) && !isset($config['prompt'])) {
            $config['prompt'] = $config['question'];
        }
        if (isset($config['correct']) && !isset($config['correctanswers'])) {
            $config['correctanswers'] = is_array($config['correct']) ? $config['correct'] : [(int)$config['correct']];
        }
        $config['options'] = array_values(array_filter($config['options'] ?? [], static function($value) {
            return trim((string)$value) !== '';
        }));
        $config['correctanswers'] = array_map('intval', $config['correctanswers'] ?? []);
        $config['multiple'] = !empty($config['multiple']);
        return $config;
    }

    public function grade_response(array $config, $response, float $maxscore, int $attemptnumber = 1, float $penalty = 0.0): grade_result {
        $config = $this->normalize_config($config);
        $submitted = $this->json_to_array($response);
        if (!$submitted) {
            $submitted = is_scalar($response) ? [(int)$response] : [];
        }
        $submitted = array_map('intval', $submitted);

        sort($submitted);
        $correct = $config['correctanswers'];
        sort($correct);
        $iscorrect = $submitted === $correct;
        $score = $iscorrect ? $this->apply_penalty($maxscore, $attemptnumber, $penalty) : 0.0;

        return new grade_result($iscorrect, $score, $iscorrect ? get_string('correct', 'mod_vidinteractivo') : get_string('incorrect', 'mod_vidinteractivo'));
    }
}
