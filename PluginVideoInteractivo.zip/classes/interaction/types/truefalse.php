<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_vidinteractivo\interaction\types;

use mod_vidinteractivo\interaction\base_element;
use mod_vidinteractivo\interaction\grade_result;

defined('MOODLE_INTERNAL') || die();

final class truefalse extends base_element {
    public function get_type(): string {
        return 'truefalse';
    }

    public function get_name(): string {
        return get_string('type_truefalse', 'mod_vidinteractivo');
    }

    public function normalize_config(array $config): array {
        $config['correct'] = !empty($config['correct']);
        return $config;
    }

    public function grade_response(array $config, $response, float $maxscore, int $attemptnumber = 1, float $penalty = 0.0): grade_result {
        $config = $this->normalize_config($config);
        $submitted = filter_var($response, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        $iscorrect = $submitted === $config['correct'];
        $score = $iscorrect ? $this->apply_penalty($maxscore, $attemptnumber, $penalty) : 0.0;
        return new grade_result($iscorrect, $score, $iscorrect ? get_string('correct', 'mod_vidinteractivo') : get_string('incorrect', 'mod_vidinteractivo'));
    }
}
