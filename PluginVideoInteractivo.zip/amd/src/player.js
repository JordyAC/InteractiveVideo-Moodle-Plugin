// Learner player for mod_vidinteractivo.

define(['core/ajax', 'core/notification'],
function(Ajax, Notification) {

    'use strict';

    var normalizeType = function(type) {
        var aliases = {
            question: 'multiplechoice',
            flashcard: 'capture',
            true_false: 'truefalse',
            image_selection: 'imageselection',
            drag_drop: 'dragdrop',
            short_answer: 'shortanswer'
        };
        return aliases[type] || type;
    };

    var escapeHtml = function(value) {
        return String(value || '').replace(/[&<>"']/g, function(ch) {
            return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[ch];
        });
    };

    var parseContent = function(interaction) {
        try {
            return JSON.parse(interaction.content || '{}');
        } catch (e) {
            return {html: interaction.content || '', capture: interaction.content || ''};
        }
    };

    var Player = function(videoSelector, cmid) {
        this.video = document.querySelector(videoSelector);
        this.cmid = cmid;
        this.interactions = [];
        this.triggeredInteractions = {};
        this.overlay = document.querySelector('.vidinteractivo-overlay-container');
        this.activeSince = 0;

        if (this.video) {
            this.loadInteractions();
            this.bindEvents();
        }
    };

    Player.prototype.loadInteractions = function() {
        var self = this;
        return Ajax.call([{
            methodname: 'mod_vidinteractivo_get_interactions',
            args: {cmid: this.cmid}
        }])[0].done(function(response) {
            self.interactions = response.filter(function(item) {
                item.type = normalizeType(item.type);
                return item.visible;
            });
            return;
        }).fail(Notification.exception);
    };

    Player.prototype.bindEvents = function() {
        var self = this;
        this.video.addEventListener('timeupdate', function() {
            self.checkTime();
        });
        this.video.addEventListener('seeking', function() {
            if (self.overlay && self.overlay.style.display !== 'none') {
                self.video.pause();
            }
        });
    };

    Player.prototype.checkTime = function() {
        var self = this;
        var currentTime = Math.floor(this.video.currentTime);
        this.interactions.forEach(function(interaction) {
            if (currentTime === parseInt(interaction.timestamp, 10) && !self.triggeredInteractions[interaction.id]) {
                self.triggeredInteractions[interaction.id] = true;
                if (interaction.pause) {
                    self.video.pause();
                }
                self.showInteraction(interaction);
            }
        });
    };

    Player.prototype.overlayParts = function() {
        return {
            title: this.overlay.querySelector('[id^="overlay-title-"]'),
            badge: this.overlay.querySelector('[id^="overlay-badge-"]'),
            body: this.overlay.querySelector('[id^="overlay-body-"]'),
            submit: this.overlay.querySelector('[id^="overlay-btn-submit-"]'),
            cont: this.overlay.querySelector('[id^="overlay-btn-continue-"]'),
            feedback: this.overlay.querySelector('[id^="overlay-feedback-"]')
        };
    };

    Player.prototype.resetOverlay = function(parts) {
        parts.body.innerHTML = '';
        parts.feedback.innerHTML = '';
        parts.feedback.className = 'feedback-msg';
        parts.submit.style.display = 'none';
        parts.submit.disabled = false;
        parts.cont.style.display = 'none';

        var newSubmit = parts.submit.cloneNode(true);
        parts.submit.parentNode.replaceChild(newSubmit, parts.submit);
        parts.submit = newSubmit;

        var newContinue = parts.cont.cloneNode(true);
        parts.cont.parentNode.replaceChild(newContinue, parts.cont);
        parts.cont = newContinue;
        return parts;
    };

    Player.prototype.showInteraction = function(interaction) {
        if (!this.overlay) {
            return;
        }
        var self = this;
        var parts = this.resetOverlay(this.overlayParts());
        var content = parseContent(interaction);
        this.activeSince = Date.now();

        parts.title.textContent = interaction.title || content.prompt || 'Interaccion';
        parts.badge.textContent = interaction.type;
        parts.badge.className = 'badge bg-primary text-white';

        if (interaction.type === 'html') {
            this.renderHtml(parts, content);
            parts.cont.style.display = 'inline-block';
        } else if (interaction.type === 'capture') {
            this.renderCapture(parts, content);
            parts.cont.style.display = 'inline-block';
        } else if (interaction.type === 'multiplechoice') {
            this.renderMultipleChoice(parts, content);
            parts.submit.style.display = 'inline-block';
        } else if (interaction.type === 'truefalse') {
            this.renderTrueFalse(parts, content);
            parts.submit.style.display = 'inline-block';
        } else if (interaction.type === 'imageselection') {
            this.renderImageSelection(parts, content);
            parts.submit.style.display = 'inline-block';
        } else if (interaction.type === 'dragdrop') {
            this.renderDragDrop(parts, content);
            parts.submit.style.display = 'inline-block';
        } else if (interaction.type === 'shortanswer') {
            this.renderShortAnswer(parts, content);
            parts.submit.style.display = 'inline-block';
        }

        parts.submit.addEventListener('click', function() {
            var response = self.collectResponse(parts.body, interaction.type, content);
            if (response === null) {
                parts.feedback.innerHTML = '<span class="text-danger">Completa la actividad antes de enviar.</span>';
                return;
            }
            self.submitAttempt(interaction, response, parts);
        });

        parts.cont.addEventListener('click', function() {
            self.overlay.style.display = 'none';
            if (self.video) {
                self.video.play();
            }
        });

        this.overlay.style.display = 'flex';
    };

    Player.prototype.renderHtml = function(parts, content) {
        parts.body.innerHTML = '<div class="html-interaction-content">' + escapeHtml(content.html || '') + '</div>';
    };

    Player.prototype.renderCapture = function(parts, content) {
        parts.body.innerHTML = '<div class="capture-interaction-content"><p class="lead mb-0">' +
            escapeHtml(content.capture || content.message || 'Video en pausa.') + '</p></div>';
    };

    Player.prototype.renderMultipleChoice = function(parts, content) {
        var inputType = content.multiple ? 'checkbox' : 'radio';
        var options = content.options || [];
        parts.body.innerHTML = '<p class="question-prompt mb-3 lead font-weight-bold">' + escapeHtml(content.prompt || content.question || '') + '</p>' +
            '<div class="vidinteractivo-options-list">' + options.map(function(opt, index) {
                return '<label class="vidinteractivo-option-item" data-index="' + index + '">' +
                    '<input type="' + inputType + '" name="vidinteractivo-opt" value="' + index + '"> ' +
                    '<span>' + escapeHtml(opt) + '</span></label>';
            }).join('') + '</div>';
    };

    Player.prototype.renderTrueFalse = function(parts, content) {
        parts.body.innerHTML = '<p class="question-prompt mb-3 lead font-weight-bold">' + escapeHtml(content.prompt || '') + '</p>' +
            '<div class="vidinteractivo-options-list">' +
            '<label class="vidinteractivo-option-item"><input type="radio" name="vidinteractivo-tf" value="true"> Verdadero</label>' +
            '<label class="vidinteractivo-option-item"><input type="radio" name="vidinteractivo-tf" value="false"> Falso</label>' +
            '</div>';
    };

    Player.prototype.renderImageSelection = function(parts, content) {
        parts.body.innerHTML = '<p class="question-prompt mb-3 lead font-weight-bold">' + escapeHtml(content.prompt || '') + '</p>' +
            '<div class="vidinteractivo-image-question"><img src="' + escapeHtml(content.imageurl || '') + '" alt="" class="img-fluid" data-selected-x="" data-selected-y=""></div>' +
            '<div class="small mt-2 text-muted">Haz clic en la zona correcta.</div>';
        var img = parts.body.querySelector('img');
        img.addEventListener('click', function(e) {
            var rect = img.getBoundingClientRect();
            var x = ((e.clientX - rect.left) / rect.width) * 100;
            var y = ((e.clientY - rect.top) / rect.height) * 100;
            img.dataset.selectedX = x.toFixed(2);
            img.dataset.selectedY = y.toFixed(2);
            parts.body.querySelector('.small').textContent = 'Seleccion: ' + img.dataset.selectedX + '%, ' + img.dataset.selectedY + '%';
        });
    };

    Player.prototype.renderDragDrop = function(parts, content) {
        var items = content.items || [];
        var zones = content.zones || [];
        parts.body.innerHTML = '<p class="question-prompt mb-3 lead font-weight-bold">' + escapeHtml(content.prompt || '') + '</p>' +
            '<div class="vidinteractivo-drag-items">' + items.map(function(item) {
                return '<div class="vidinteractivo-draggable" draggable="true" data-item="' + escapeHtml(item) + '">' + escapeHtml(item) + '</div>';
            }).join('') + '</div>' +
            '<div class="vidinteractivo-dropzones">' + zones.map(function(zone) {
                return '<div class="vidinteractivo-dropzone" data-zone="' + escapeHtml(zone) + '"><strong>' + escapeHtml(zone) + '</strong><span></span></div>';
            }).join('') + '</div>';

        parts.body.querySelectorAll('.vidinteractivo-draggable').forEach(function(item) {
            item.addEventListener('dragstart', function(e) {
                e.dataTransfer.setData('text/plain', item.dataset.item);
            });
        });
        parts.body.querySelectorAll('.vidinteractivo-dropzone').forEach(function(zone) {
            zone.addEventListener('dragover', function(e) {
                e.preventDefault();
            });
            zone.addEventListener('drop', function(e) {
                e.preventDefault();
                zone.dataset.item = e.dataTransfer.getData('text/plain');
                zone.querySelector('span').textContent = zone.dataset.item;
            });
        });
    };

    Player.prototype.renderShortAnswer = function(parts, content) {
        parts.body.innerHTML = '<p class="question-prompt mb-3 lead font-weight-bold">' + escapeHtml(content.prompt || '') + '</p>' +
            '<input type="text" class="form-control" name="vidinteractivo-shortanswer">';
    };

    Player.prototype.collectResponse = function(body, type, content) {
        if (type === 'multiplechoice') {
            var selected = Array.prototype.slice.call(body.querySelectorAll('input[name="vidinteractivo-opt"]:checked')).map(function(input) {
                return parseInt(input.value, 10);
            });
            if (!selected.length) {
                return null;
            }
            return JSON.stringify(selected);
        }
        if (type === 'truefalse') {
            var tf = body.querySelector('input[name="vidinteractivo-tf"]:checked');
            return tf ? tf.value : null;
        }
        if (type === 'imageselection') {
            var img = body.querySelector('img');
            if (!img || img.dataset.selectedX === '') {
                return null;
            }
            return JSON.stringify({x: parseFloat(img.dataset.selectedX), y: parseFloat(img.dataset.selectedY)});
        }
        if (type === 'dragdrop') {
            var mapping = {};
            var complete = true;
            body.querySelectorAll('.vidinteractivo-dropzone').forEach(function(zone) {
                if (!zone.dataset.item) {
                    complete = false;
                }
                mapping[zone.dataset.item || ''] = zone.dataset.zone;
            });
            return complete ? JSON.stringify(mapping) : null;
        }
        if (type === 'shortanswer') {
            var answer = body.querySelector('[name="vidinteractivo-shortanswer"]').value.trim();
            return answer === '' ? null : answer;
        }
        return '';
    };

    Player.prototype.submitAttempt = function(interaction, response, parts) {
        var timetaken = Math.max(0, Math.round((Date.now() - this.activeSince) / 1000));
        parts.submit.disabled = true;

        return Ajax.call([{
            methodname: 'mod_vidinteractivo_save_attempt',
            args: {
                cmid: this.cmid,
                interactionid: interaction.id,
                response: response,
                timetaken: timetaken
            }
        }])[0].done(function(result) {
            parts.submit.style.display = 'none';
            parts.cont.style.display = 'inline-block';
            parts.feedback.innerHTML = result.iscorrect ?
                '<span class="text-success"><i class="fa fa-check-circle"></i> ' + escapeHtml(result.feedback || 'Respuesta correcta') + '</span>' :
                '<span class="text-danger"><i class="fa fa-times-circle"></i> ' + escapeHtml(result.feedback || 'Respuesta incorrecta') + '</span>';
            parts.body.querySelectorAll('input, button, select, textarea').forEach(function(el) {
                el.disabled = true;
            });
            parts.body.querySelectorAll('.vidinteractivo-draggable').forEach(function(el) {
                el.setAttribute('draggable', 'false');
            });
            return;
        }).fail(function(ex) {
            parts.submit.disabled = false;
            Notification.exception(ex);
        });
    };

    return {
        init: function(videoSelector, cmid) {
            return new Player(videoSelector, cmid);
        }
    };
});
