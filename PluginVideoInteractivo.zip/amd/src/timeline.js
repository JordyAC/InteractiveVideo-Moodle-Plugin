// Authoring UI for mod_vidinteractivo.

define(['core/ajax', 'core/notification', 'core/templates', 'core/modal_factory', 'core/modal_events'],
function(Ajax, Notification, Templates, ModalFactory, ModalEvents) {

    'use strict';

    var TYPES = [
        {value: 'html', label: 'Contenido HTML / texto'},
        {value: 'capture', label: 'Pausa informativa'},
        {value: 'multiplechoice', label: 'Opcion multiple'},
        {value: 'truefalse', label: 'Verdadero / Falso'},
        {value: 'imageselection', label: 'Seleccion sobre imagen'},
        {value: 'dragdrop', label: 'Arrastrar y soltar'},
        {value: 'shortanswer', label: 'Respuesta corta'}
    ];

    var normalizeType = function(type) {
        var aliases = {
            question: 'multiplechoice',
            flashcard: 'capture',
            true_false: 'truefalse',
            image_selection: 'imageselection',
            drag_drop: 'dragdrop',
            short_answer: 'shortanswer'
        };
        return aliases[type] || type;
    };

    var splitLines = function(value) {
        return (value || '').split(/\r?\n/).map(function(line) {
            return line.trim();
        }).filter(Boolean);
    };

    var parseCsvNumbers = function(value) {
        return (value || '').split(',').map(function(item) {
            return parseInt(item.trim(), 10);
        }).filter(function(item) {
            return !isNaN(item);
        });
    };

    var parseAreas = function(value) {
        return splitLines(value).map(function(line) {
            var parts = line.split(',').map(function(item) {
                return item.trim();
            });
            return {
                x: parseFloat(parts[0]) || 0,
                y: parseFloat(parts[1]) || 0,
                width: parseFloat(parts[2]) || 0,
                height: parseFloat(parts[3]) || 0,
                correct: parts[4] === undefined ? true : /^(1|true|si|sí|yes)$/i.test(parts[4])
            };
        });
    };

    var parseMapping = function(value) {
        var mapping = {};
        splitLines(value).forEach(function(line) {
            var parts = line.split('=');
            if (parts.length === 2) {
                mapping[parts[0].trim()] = parts[1].trim();
            }
        });
        return mapping;
    };

    var mappingToText = function(mapping) {
        return Object.keys(mapping || {}).map(function(key) {
            return key + '=' + mapping[key];
        }).join('\n');
    };

    var areasToText = function(areas) {
        return (areas || []).map(function(area) {
            return [area.x || 0, area.y || 0, area.width || 0, area.height || 0, area.correct ? 1 : 0].join(',');
        }).join('\n');
    };

    var escapeHtml = function(value) {
        return String(value || '').replace(/[&<>"']/g, function(ch) {
            return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[ch];
        });
    };

    var Timeline = function(videoSelector, cmid) {
        this.video = document.querySelector(videoSelector);
        this.cmid = cmid;
        this.markers = [];
        this.bindAddButton();
        this.loadMarkers();
    };

    Timeline.prototype.bindAddButton = function() {
        var self = this;
        var btn = document.getElementById('vidinteractivo-add-marker');
        if (btn) {
            btn.addEventListener('click', function() {
                self.openAuthoringModal();
            });
        }
    };

    Timeline.prototype.getCurrentTime = function() {
        return Math.floor(this.video ? this.video.currentTime : 0);
    };

    Timeline.prototype.loadMarkers = function() {
        var self = this;
        return Ajax.call([{
            methodname: 'mod_vidinteractivo_get_interactions',
            args: {cmid: this.cmid}
        }])[0].done(function(response) {
            self.markers = response.map(function(marker) {
                marker.type = normalizeType(marker.type);
                return marker;
            });
            self.renderTimelineMarkers();
            self.renderAuthoringPanel();
            return;
        }).fail(Notification.exception);
    };

    Timeline.prototype.emptyContentData = function() {
        return {
            html: '',
            capture: '',
            prompt: '',
            options: '',
            correctanswers: '0',
            multiple: false,
            trueSelected: true,
            falseSelected: false,
            imageurl: '',
            areas: '10,10,30,30,1',
            items: '',
            zones: '',
            mapping: '',
            answers: '',
            casesensitive: false
        };
    };

    Timeline.prototype.contentForModal = function(marker) {
        var data = this.emptyContentData();
        if (!marker || !marker.content) {
            return data;
        }

        var parsed = {};
        try {
            parsed = JSON.parse(marker.content);
        } catch (e) {
            parsed = {};
        }

        data.html = parsed.html || '';
        data.capture = parsed.capture || parsed.message || '';
        data.prompt = parsed.prompt || parsed.question || '';
        data.options = (parsed.options || []).join('\n');
        data.correctanswers = (parsed.correctanswers || (parsed.correct !== undefined ? [parsed.correct] : [0])).join(',');
        data.multiple = !!parsed.multiple;
        data.trueSelected = parsed.correct !== false;
        data.falseSelected = parsed.correct === false;
        data.imageurl = parsed.imageurl || parsed.image || '';
        data.areas = areasToText(parsed.areas || []);
        data.items = (parsed.items || []).join('\n');
        data.zones = (parsed.zones || []).join('\n');
        data.mapping = mappingToText(parsed.mapping || {});
        data.answers = (parsed.answers || []).join('\n');
        data.casesensitive = !!parsed.casesensitive;
        return data;
    };

    Timeline.prototype.openAuthoringModal = function(existingMarker) {
        var self = this;
        var marker = existingMarker || {};
        var timestamp = existingMarker ? parseInt(marker.timestamp, 10) : this.getCurrentTime();
        var type = normalizeType(marker.type || 'multiplechoice');
        var interactionid = existingMarker ? marker.id : 0;

        if (this.video) {
            this.video.pause();
        }

        var typesContext = TYPES.map(function(t) {
            return {value: t.value, label: t.label, selected: type === t.value};
        });

        Templates.render('mod_vidinteractivo/add_interaction_modal', {
            timestamp: timestamp,
            timeend: marker.timeend || 0,
            title: marker.title || '',
            types: typesContext,
            contentData: this.contentForModal(existingMarker),
            maxscore: marker.maxscore === undefined ? 1 : marker.maxscore,
            attemptsallowed: marker.attemptsallowed === undefined ? 1 : marker.attemptsallowed,
            penalty: marker.penalty || 0,
            required: marker.required === undefined ? true : marker.required,
            pause: marker.pause === undefined ? true : marker.pause
        }).then(function(html) {
            return ModalFactory.create({
                title: existingMarker ? 'Editar interaccion' : 'Agregar interaccion',
                body: html
            });
        }).then(function(modal) {
            modal.show();
            var root = modal.getRoot()[0];
            var typeSelect = root.querySelector('[name="type"]');
            var sections = root.querySelectorAll('.interaction-type-section');

            var updateVisibility = function() {
                sections.forEach(function(section) {
                    section.style.display = section.id === 'sec-' + typeSelect.value ? 'block' : 'none';
                });
            };

            typeSelect.addEventListener('change', updateVisibility);
            updateVisibility();

            root.querySelector('[data-action="cancel"]').addEventListener('click', function() {
                modal.hide();
            });

            root.querySelector('[data-action="save-interaction"]').addEventListener('click', function() {
                var selectedType = typeSelect.value;
                var config = self.buildConfig(root, selectedType);
                self.saveMarker(interactionid, {
                    timestamp: parseInt(root.querySelector('[name="timestamp"]').value, 10) || 0,
                    timeend: parseInt(root.querySelector('[name="timeend"]').value, 10) || 0,
                    type: selectedType,
                    title: root.querySelector('[name="interaction-title"]').value,
                    content: JSON.stringify(config),
                    maxscore: parseFloat(root.querySelector('[name="maxscore"]').value) || 0,
                    attemptsallowed: parseInt(root.querySelector('[name="attemptsallowed"]').value, 10) || 0,
                    penalty: parseFloat(root.querySelector('[name="penalty"]').value) || 0,
                    required: root.querySelector('[name="required"]').checked,
                    pause: root.querySelector('[name="pause"]').checked
                });
                modal.hide();
            });

            modal.getRoot().on(ModalEvents.hidden, function() {
                modal.destroy();
            });
            return;
        }).catch(Notification.exception);
    };

    Timeline.prototype.buildConfig = function(root, type) {
        if (type === 'html') {
            return {html: root.querySelector('[name="html-text"]').value};
        }
        if (type === 'capture') {
            return {capture: root.querySelector('[name="capture-text"]').value};
        }
        if (type === 'multiplechoice') {
            return {
                prompt: root.querySelector('[name="mcq-prompt"]').value,
                options: splitLines(root.querySelector('[name="mcq-options"]').value),
                correctanswers: parseCsvNumbers(root.querySelector('[name="mcq-correct"]').value),
                multiple: root.querySelector('[name="mcq-multiple"]').checked
            };
        }
        if (type === 'truefalse') {
            return {
                prompt: root.querySelector('[name="tf-prompt"]').value,
                correct: root.querySelector('[name="tf-correct"]').value === 'true'
            };
        }
        if (type === 'imageselection') {
            return {
                prompt: root.querySelector('[name="image-prompt"]').value,
                imageurl: root.querySelector('[name="image-url"]').value,
                areas: parseAreas(root.querySelector('[name="image-areas"]').value)
            };
        }
        if (type === 'dragdrop') {
            return {
                prompt: root.querySelector('[name="drag-prompt"]').value,
                items: splitLines(root.querySelector('[name="drag-items"]').value),
                zones: splitLines(root.querySelector('[name="drag-zones"]').value),
                mapping: parseMapping(root.querySelector('[name="drag-mapping"]').value)
            };
        }
        if (type === 'shortanswer') {
            return {
                prompt: root.querySelector('[name="short-prompt"]').value,
                answers: splitLines(root.querySelector('[name="short-answers"]').value),
                casesensitive: root.querySelector('[name="short-casesensitive"]').checked
            };
        }
        return {};
    };

    Timeline.prototype.saveMarker = function(interactionid, marker) {
        var self = this;
        return Ajax.call([{
            methodname: 'mod_vidinteractivo_save_interaction',
            args: Object.assign({cmid: this.cmid, interactionid: interactionid, visible: true}, marker)
        }])[0].done(function() {
            self.loadMarkers();
            return;
        }).fail(Notification.exception);
    };

    Timeline.prototype.deleteMarker = function(interactionid) {
        var self = this;
        if (!confirm('Seguro que deseas eliminar esta interaccion? Tambien se eliminaran sus respuestas.')) {
            return;
        }
        return Ajax.call([{
            methodname: 'mod_vidinteractivo_delete_interaction',
            args: {cmid: this.cmid, interactionid: interactionid}
        }])[0].done(function() {
            self.loadMarkers();
            return;
        }).fail(Notification.exception);
    };

    Timeline.prototype.renderTimelineMarkers = function() {
        var bar = document.querySelector('.vidinteractivo-progressbar');
        if (!bar || !this.video || isNaN(this.video.duration) || this.video.duration === 0) {
            var self = this;
            setTimeout(function() {
                self.renderTimelineMarkers();
            }, 500);
            return;
        }
        bar.innerHTML = '';
        var duration = this.video.duration;
        this.markers.forEach(function(marker) {
            if (!marker.visible) {
                return;
            }
            var el = document.createElement('span');
            el.className = 'vidinteractivo-marker marker-' + marker.type;
            el.title = marker.type + ' @ ' + marker.timestamp + 's';
            el.style.left = (marker.timestamp / duration * 100) + '%';
            bar.appendChild(el);
        });
    };

    Timeline.prototype.renderAuthoringPanel = function() {
        var panel = document.getElementById('vidinteractivo-authoring-list');
        if (!panel) {
            return;
        }
        var self = this;
        if (!this.markers.length) {
            panel.innerHTML = '<div class="alert alert-info text-center py-3">No hay interacciones configuradas.</div>';
            return;
        }

        panel.innerHTML = '';
        var table = document.createElement('table');
        table.className = 'table table-hover table-striped align-middle';
        table.innerHTML = '<thead><tr><th>Tiempo</th><th>Tipo</th><th>Detalle</th><th>Puntos</th><th>Acciones</th></tr></thead><tbody></tbody>';
        var tbody = table.querySelector('tbody');

        this.markers.forEach(function(marker) {
            var parsed = {};
            try {
                parsed = JSON.parse(marker.content || '{}');
            } catch (e) {
                parsed = {};
            }
            var typeLabel = TYPES.find(function(t) {
                return t.value === marker.type;
            });
            var desc = marker.title || parsed.prompt || parsed.question || parsed.capture || parsed.html || '';
            var tr = document.createElement('tr');
            tr.innerHTML =
                '<td><strong>' + marker.timestamp + 's</strong></td>' +
                '<td><span class="badge badge-info type-badge-' + escapeHtml(marker.type) + '">' + escapeHtml(typeLabel ? typeLabel.label : marker.type) + '</span></td>' +
                '<td><small>' + escapeHtml(desc).substring(0, 100) + '</small></td>' +
                '<td>' + escapeHtml(marker.maxscore) + '</td>' +
                '<td>' +
                    '<button class="btn btn-sm btn-outline-primary btn-edit" data-id="' + marker.id + '"><i class="fa fa-pencil"></i></button> ' +
                    '<button class="btn btn-sm btn-outline-danger btn-delete" data-id="' + marker.id + '"><i class="fa fa-trash"></i></button>' +
                '</td>';
            tr.querySelector('.btn-edit').addEventListener('click', function() {
                self.openAuthoringModal(marker);
            });
            tr.querySelector('.btn-delete').addEventListener('click', function() {
                self.deleteMarker(marker.id);
            });
            tbody.appendChild(tr);
        });

        panel.appendChild(table);
    };

    return {
        init: function(videoSelector, cmid) {
            return new Timeline(videoSelector, cmid);
        }
    };
});
